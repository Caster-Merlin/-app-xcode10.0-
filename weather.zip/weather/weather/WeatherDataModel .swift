//
//  WeatherDataModel .swift
//  weather
//
//  Created by hzw on 2019/1/9.
//  Copyright © 2019年 hzw. All rights reserved.
//

import UIKit

class WeatherDataModel{
    
    //声明天气程序变量
    var temperature : Int = 0
    var condition : String = ""
    var city : String = ""
    var weather : String = ""
    var weatherIconName : String = ""
    var humidity : String = ""
    var time : String = ""
    var date_y : String = ""
    var wind_strength : String = ""
    var weatherQualityIconName : String = ""
    var qualityCondition : Int = 0
    
    //未来天气预报
    //var daily: [Future]?
    var date:[String] = ["无数据", "无数据", "无数据", "无数据", "无数据", "无数据", "无数据"]
    var week:[String] = ["无数据", "无数据", "无数据", "无数据", "无数据", "无数据", "无数据"]
    var temp:[String] = ["无数据", "无数据", "无数据", "无数据", "无数据", "无数据", "无数据"]
    var futureIconName:[String] = ["无数据", "无数据", "无数据", "无数据", "无数据", "无数据", "无数据"]
    var futureCondition : String = ""
    
    //更换天气图片的方法
    func updateWeatherIcon(condition: String) -> String {
        
        switch (condition) {
            
        case "00":
            return "sun"
        
        case "01":
            return "sun_to_cloudy"
            
        case "02":
            return "cloudy"
            
        case "03":
            return "zhenyu_b"
            
        case "04":
            return "thunder"
            
        case "05":
            return "hailstone"
            
        case "06":
            return "snow_and_rain"
            
        case "07":
            return "rain_s"
            
        case "08","19","21":
            return "rain_m"
            
        case "09","10","11","12","22","23","24":
            return "rain_b"
            
        case "13","14":
            return "snow_s"
            
        case "15","26":
            return "snow_m"
            
        case "16","17":
            return "snow_b"
            
        case "18","53","27","28":
            return "fog_and_haze"
            
        case "20","29","30","31":
            return "dust"
            
        default:
            return "dunno"
        }
    }
    //更新空气质量图标
    func updateQualityWeatherIcon(qualityCondition: Int) -> String {
        switch qualityCondition {
        case 0...50:
            return "nice"
        case 51...100:
            return "ok"
        default:
            return "bad"
        }
    }
}
