//
//  FutureCollectionViewCell.swift
//  weather
//
//  Created by hzw on 2019/1/12.
//  Copyright © 2019年 hzw. All rights reserved.
//

import UIKit

class FutureCollectionViewCell: UICollectionViewCell {
    //星期
    @IBOutlet weak var weekLabel: UILabel!
    //天气图标
    @IBOutlet weak var iconView: UIImageView!
    //气温
    @IBOutlet weak var tempLabel: UILabel!
}
