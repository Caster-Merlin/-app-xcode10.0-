//
//  ViewController.swift
//  weather
//
//  Created by hzw on 2019/1/4.
//  Copyright © 2019年 hzw. All rights reserved.
//

import UIKit
import CoreLocation
import Alamofire
import SwiftyJSON

class ViewController: UIViewController, CLLocationManagerDelegate,UITableViewDelegate,UICollectionViewDataSource,UICollectionViewDelegate,UICollectionViewDelegateFlowLayout,ChangeCityDelegate{

    @IBOutlet weak var faren: UISwitch!
    @IBAction func `switch`(_ sender: Any) {
        if (sender as AnyObject).isOn{
            
        }
    }
    @IBOutlet weak var weatherIcon: UIImageView!
    @IBOutlet weak var cityLabel: UILabel!
    @IBOutlet weak var temperatureLabel: UILabel!
    @IBOutlet weak var weatherLabel: UILabel!
    @IBOutlet weak var updatatimeLabel: UILabel!
    @IBOutlet weak var windspeedLabel: UILabel!
    @IBOutlet weak var humidityLabel: UILabel!
    @IBOutlet weak var weatherQualityLabel: UILabel!
    @IBOutlet weak var weatherQualityIcon: UIImageView!
    @IBOutlet weak var button: UIButton!
    //未来七天天气列表
    @IBOutlet weak var FutureCollectionView: UICollectionView!
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 7
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "FutureCell", for: indexPath)
        if let futureCell = cell as? FutureCollectionViewCell{
            futureCell.weekLabel.text = weatherDataModel.week[indexPath.item]
            futureCell.tempLabel.text = weatherDataModel.temp[indexPath.item]
            futureCell.iconView.image = UIImage(named: weatherDataModel.futureIconName[indexPath.item])
        }
        return cell
    }
    
    //去数据有关的地址信息
    let URL1 = "http://v.juhe.cn/weather/index"
    let URL2 = "http://v.juhe.cn/weather/geo"
    let APP_ID = "b6eee3ae3541a2f716ee2389817e78b3"
    //声明实例变量
    let locationManager = CLLocationManager()
    let weatherDataModel = WeatherDataModel()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyHundredMeters
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
        
        FutureCollectionView.dataSource = self
        FutureCollectionView.delegate = self
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    //获取查询天气数据
    func getWeatherData(cityName: String) {
        let urlStr = URL1 + "?format=2&cityname=" + cityName + "&key=" + APP_ID
        
        // 带中文的URL创建 必须将编码方式改为utf8 否则 URL为空
        let encodedUrl = urlStr.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlQueryAllowed)!
        let url = URL(string: encodedUrl)
        
        Alamofire.request(url!, method: .get).responseJSON{
            responds in
            if responds.result.isSuccess{
                print("获取成功")
                let weatherJSON: JSON = JSON(responds.result.value!)
                
                print(weatherJSON)
                
                self.updateWeatherData(json: weatherJSON)
            }else{
                print("Error \(String(describing: responds.result.error))")
                self.cityLabel.text = "网络连接失败！！！"
            }
        }
    }
    
    //定位查询天气数据
    func locationWeatherData(lon: String, lat: String) {
         let url = URL2 + "?format=2&key=" + APP_ID + "&lon=" + lon + "&lat=" + lat
        
        Alamofire.request(url, method: .get).responseJSON{
            responds in
            if responds.result.isSuccess{
                print("获取成功")
                let weatherJSON: JSON = JSON(responds.result.value!)
                
                print(weatherJSON)
                
                self.updateWeatherData(json: weatherJSON)
            }else{
                print("Error \(String(describing: responds.result.error))")
                self.cityLabel.text = "网络连接失败！！！"
            }
        }
    }
    
    //天气信息更新的方法
    func updateWeatherData(json: JSON) {
        let tempResult = json["result"]["sk"]["temp"].doubleValue
        weatherDataModel.temperature = Int(tempResult)
        
        weatherDataModel.city = json["result"]["today"]["city"].stringValue
        
        weatherDataModel.condition = json["result"]["today"]["weather_id"]["fa"].stringValue
        
        weatherDataModel.weatherIconName = weatherDataModel.updateWeatherIcon(condition: weatherDataModel.condition)
        
        weatherDataModel.qualityCondition = json["result"]["today"]["weather_id"]["fb"].intValue
        
        weatherDataModel.weatherQualityIconName = weatherDataModel.updateQualityWeatherIcon(qualityCondition: weatherDataModel.qualityCondition)
        
        weatherDataModel.weather = json["result"]["today"]["weather"].stringValue
        
        weatherDataModel.wind_strength = json["result"]["sk"]["wind_strength"].stringValue
        
        weatherDataModel.humidity = json["result"]["sk"]["humidity"].stringValue
        
        weatherDataModel.date_y = json["result"]["today"]["date_y"].stringValue
        
        weatherDataModel.time = json["result"]["sk"]["time"].stringValue
        
        for i in 0...6{
            weatherDataModel.date[i] = json["result"]["future"][i]["date"].stringValue
            weatherDataModel.week[i] = json["result"]["future"][i]["week"].stringValue
            weatherDataModel.temp[i] = json["result"]["future"][i]["temperature"].stringValue
            weatherDataModel.futureCondition = json["result"]["future"][i]["weather_id"]["fa"].stringValue
            weatherDataModel.futureIconName[i] = weatherDataModel.updateWeatherIcon(condition: weatherDataModel.futureCondition)
        }
        
        self.FutureCollectionView.reloadData()
        
        updateUIWithWeatherData()
    }
    
    //更新界面中的天气信息的方法
    func updateUIWithWeatherData() {
        cityLabel.text = weatherDataModel.city
        temperatureLabel.text = "\(weatherDataModel.temperature)"
        weatherIcon.image = UIImage(named: weatherDataModel.weatherIconName)
        weatherLabel.text = weatherDataModel.weather
        windspeedLabel.text = weatherDataModel.wind_strength
        humidityLabel.text = weatherDataModel.humidity
        updatatimeLabel.text = weatherDataModel.date_y + weatherDataModel.time
        weatherQualityLabel.text = String(weatherDataModel.qualityCondition)
        weatherQualityIcon.image = UIImage(named: weatherDataModel.weatherQualityIconName)
    }
    
    //更新定位的方法
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let location = locations[locations.count - 1]
        if location.horizontalAccuracy > 0 {
            
            self.locationManager.stopUpdatingLocation()
            
            print("经度 = \(location.coordinate.longitude), 纬度 = \(location.coordinate.latitude)")
            
            let latitude = String(location.coordinate.latitude)
            let longitude = String(location.coordinate.longitude)
            
            print(longitude, latitude)
            
            locationWeatherData(lon: longitude, lat: latitude)
        }
    }
    
    //定位失败
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print(error)
        cityLabel.text = "定位失败"
    }
    
    //查询更新的方法
    func userEnteredANewCityName(city: String) {
        getWeatherData(cityName: city)
    }
    
    //查询后更新界面
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let destinationVC = segue.destination as! ChangeCityViewController
        destinationVC.delegate = self
    }
}

